#ifndef __RECORD_H__
#define __RECORD_H__

struct Record
{
    int id;
    char name[15];
    char surname[25];
    char address[50];
};

#endif // __RECORD_H__